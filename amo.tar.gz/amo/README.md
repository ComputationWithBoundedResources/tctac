
Install using

    `stack build`

Run with

    `stack exec tct -- --complexity rci -t $TIMEOUT -s $STRATEGY $PROBLEFILE`

List strategies with

    `stack exec tct -- --list`

Strategies are defined in `Trs.hs`

